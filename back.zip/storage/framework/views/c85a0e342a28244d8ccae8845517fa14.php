<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/claudio/Projects/back-geriatrico/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>