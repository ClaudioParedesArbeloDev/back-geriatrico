<?php echo e($slot); ?>

<?php /**PATH /home/claudio/Projects/back-geriatrico/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>